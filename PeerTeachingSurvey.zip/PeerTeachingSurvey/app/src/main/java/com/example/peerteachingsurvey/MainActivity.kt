package com.example.peerteachingsurvey

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.peerteachingsurvey.ui.theme.PeerTeachingSurveyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PeerTeachingSurveyTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    DashboardScreen(
                        modifier = Modifier.padding(innerPadding),
                        onTakeSurveyClick = {
                            // Navigate to SurveyActivity
                            val intent = Intent(this, SurveyActivity::class.java)
                            startActivity(intent)
                        },
                        onViewSummaryClick = {
                            // Navigate to SummaryActivity
                            val intent = Intent(this, SummaryActivity::class.java)
                            startActivity(intent)
                        },
                        onEmailResultClick = {
                            // Navigate to EmailActivity
                            val intent = Intent(this, EmailActivity::class.java)
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(
    modifier: Modifier = Modifier,
    onTakeSurveyClick: () -> Unit,
    onViewSummaryClick: () -> Unit,
    onEmailResultClick: () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Peer Teaching Survey",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Take Survey Button
        Button(
            onClick = onTakeSurveyClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Text(text = "Take Survey")
        }

        // View Summary Button
        Button(
            onClick = onViewSummaryClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Text(text = "View Summary")
        }

        // Email Result Button
        Button(
            onClick = onEmailResultClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Text(text = "Email Result")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DashboardScreenPreview() {
    PeerTeachingSurveyTheme {
        DashboardScreen(
            onTakeSurveyClick = {},
            onViewSummaryClick = {},
            onEmailResultClick = {}
        )
    }
}