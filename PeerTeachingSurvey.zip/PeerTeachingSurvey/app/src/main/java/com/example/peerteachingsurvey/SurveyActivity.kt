package com.example.peerteachingsurvey

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.peerteachingsurvey.databinding.ActivitySurveyBinding

class SurveyActivity : AppCompatActivity() {

    // Declare View Binding
    private lateinit var binding: ActivitySurveyBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize View Binding
        binding = ActivitySurveyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Submit button click listener
        binding.submitButton.setOnClickListener {
            // Collect responses
            val q1Score = getSelectedScore(binding.radioGroup)
            val q2Score = getSelectedScore(binding.radioGroup1)
            val q3Score = getSelectedScore(binding.q3Group)
            val q4Score = getSelectedScore(binding.q4Group)
            val q5Score = getSelectedScore(binding.q5Group)
            val q6Score = getSelectedScore(binding.q6Group)

            // Save responses to SharedPreferences
            val sharedPref = getSharedPreferences("SurveyResults", Context.MODE_PRIVATE)
            with(sharedPref.edit()) {
                putInt("Q1", q1Score)
                putInt("Q2", q2Score)
                putInt("Q3", q3Score)
                putInt("Q4", q4Score)
                putInt("Q5", q5Score)
                putInt("Q6", q6Score)
                apply()
            }

            // Navigate to SummaryActivity
            val intent = Intent(this, SummaryActivity::class.java)
            startActivity(intent)
        }
    }

    // Helper function to get the selected score from a RadioGroup
    private fun getSelectedScore(radioGroup: radioGroup): Int {
        return when (radioGroup.checkedRadioButtonId) {
            R.id.radioButton1, R.id.radioButton6, R.id.radioButton21, R.id.radioButton26, R.id.radioButton31, R.id.radioButton36 -> 1
            R.id.radioButton2, R.id.radioButton7, R.id.radioButton22, R.id.radioButton27, R.id.radioButton32, R.id.radioButton37 -> 2
            R.id.radioButton3, R.id.radioButton8, R.id.radioButton23, R.id.radioButton28, R.id.radioButton33, R.id.radioButton38 -> 3
            R.id.radioButton4, R.id.radioButton9, R.id.radioButton24, R.id.radioButton29, R.id.radioButton34, R.id.radioButton39 -> 4
            R.id.radioButton5, R.id.radioButton10, R.id.radioButton25, R.id.radioButton30, R.id.radioButton35, R.id.radioButton40 -> 5
            else -> 0 // No selection
        }
    }
}