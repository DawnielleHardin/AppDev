package com.example.peerteachingsurvey

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.utils.ColorTemplate

class SummaryActivity : AppCompatActivity() {

    private lateinit var barChart: BarChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_summary)

        // Initialize BarChart
        barChart = findViewById(R.id.barChart)

        // Example data for the BarChart
        val entries = ArrayList<BarEntry>()
        entries.add(BarEntry(1f, 4f)) // Question 1 score
        entries.add(BarEntry(2f, 3f)) // Question 2 score
        entries.add(BarEntry(3f, 5f)) // Question 3 score
        entries.add(BarEntry(4f, 2f)) // Question 4 score
        entries.add(BarEntry(5f, 4f)) // Question 5 score
        entries.add(BarEntry(6f, 3f)) // Question 6 score

        // Create a BarDataSet
        val dataSet = BarDataSet(entries, "Survey Results")
        dataSet.colors = ColorTemplate.COLORFUL_COLORS.toList()

        // Create BarData and set it to the BarChart
        val barData = BarData(dataSet)
        barChart.data = barData

        // Customize the BarChart
        barChart.setFitBars(true)
        barChart.description.text = "Question Scores"
        barChart.animateY(1000) // Add animation
    }
}